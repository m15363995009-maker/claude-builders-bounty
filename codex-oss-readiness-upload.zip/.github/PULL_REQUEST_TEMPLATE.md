## Summary

<!-- What changed and why? Keep this factual and concise. -->

## Scope and acceptance criteria

- [ ] The change addresses the linked issue or stated maintainer task.
- [ ] The acceptance criteria are listed or linked below.

## Verification

- Tests run:
- Manual checks, if any:
- Known limitations:

## Security and permissions

- [ ] No secrets, private diffs, or personal data were added.
- [ ] GitHub token permissions and untrusted-input handling were considered.
- [ ] This change does not execute contributor-controlled code in a privileged workflow.

## Documentation and release notes

- [ ] Documentation was updated when behavior or configuration changed.
- [ ] `CHANGELOG.md` was updated when the change is user-visible.
